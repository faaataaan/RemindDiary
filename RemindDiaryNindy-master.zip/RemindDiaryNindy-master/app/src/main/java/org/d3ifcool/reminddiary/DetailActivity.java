package org.d3ifcool.reminddiary;

import android.app.DatePickerDialog;
import android.content.ContentValues;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.TextView;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;

import static org.d3ifcool.reminddiary.DatabaseContract.DiaryEntry.COLUMN_BODY;
import static org.d3ifcool.reminddiary.DatabaseContract.DiaryEntry.COLUMN_TITLE;
import static org.d3ifcool.reminddiary.DatabaseContract.DiaryEntry.TABLE_NAME;

public class DetailActivity extends AppCompatActivity {

    RemindModel data;

    private EditText title, date , desc;
    @Override

    protected void onCreate(Bundle savedInstanceState) {



        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);

        title = findViewById(R.id.detail_title);
        date = findViewById(R.id.detail_time);
        desc = findViewById(R.id.detail_description);
        data = getIntent().getParcelableExtra("DATA");

        title.setText(data.getTitle());
        date.setText(data.getDate());
        desc.setText(data.getDescription());

        final EditText date = findViewById(R.id.detail_time);
        final View datepicker = findViewById(R.id.date_picker);
        datepicker.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Calendar newCalendar = Calendar.getInstance();

                DatePickerDialog datePickerDialog = new DatePickerDialog(DetailActivity.this, new DatePickerDialog.OnDateSetListener() {

                    @Override
                    public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {

                        Calendar newDate = Calendar.getInstance();
                        newDate.set(year, monthOfYear, dayOfMonth);
                        SimpleDateFormat dateFormatter = new SimpleDateFormat("dd-MM-yyyy", Locale.US);
                        date.setText(dateFormatter.format(newDate.getTime()));
                    }

                },newCalendar.get(Calendar.YEAR), newCalendar.get(Calendar.MONTH), newCalendar.get(Calendar.DAY_OF_MONTH));

                datePickerDialog.show();
            }
        });
    }



    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu_delete, menu);
        inflater.inflate(R.menu.menu_update, menu);
        return true;
    }

    public void deleteEntries(){
        String selection = DatabaseContract.DiaryEntry._ID+ " LIKE ?";
// Specify arguments in placeholder order.
        String [] selectionArgs = { data.getId()+"" };
// Issue SQL statement.
        DBHELPER dbHelper = new DBHELPER(this);
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        int deletedRows = db.delete(DatabaseContract.DiaryEntry.TABLE_NAME, selection, selectionArgs);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        Intent i = new Intent(this, MainActivity.class);
        switch(item.getItemId ()) {
            case R.id.delete:
                deleteEntries ();
                finish ();
                finish ();
                startActivity(i);
                break;
            case R.id.update:
                updateDiary ();
                finish ();
                finish ();
                startActivity(i);
                break;
        }
        return true;
    }

    public void updateDiary(){
        DBHELPER dbHelper = new DBHELPER(this);
        SQLiteDatabase db = dbHelper.getWritableDatabase();



    // New value for one column
        String id = data.getId()+"" ;
        ContentValues values = new ContentValues ();
        values.put(DatabaseContract.DiaryEntry.COLUMN_TITLE,title.getText ().toString ());
        values.put(DatabaseContract.DiaryEntry.COLUMN_DATE, date.getText ().toString ());
        values.put(DatabaseContract.DiaryEntry.COLUMN_BODY, desc.getText ().toString ());


// Which row to update, based on the title
        String selection = DatabaseContract.DiaryEntry._ID + " LIKE ?";
        String[] selectionArgs = { id };

        int count = db.update(
                DatabaseContract.DiaryEntry.TABLE_NAME,
                values,
                selection,
                selectionArgs);
    }

}



