package org.d3ifcool.reminddiary;

import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import android.os.Build;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import org.w3c.dom.Text;

import java.util.ArrayList;

public class RemindAdapter extends RecyclerView.Adapter<RemindAdapter.ViewHolder> {
    private ArrayList<RemindModel> models;
    private Context ctx;

    public RemindAdapter(Context ctx, ArrayList<RemindModel> models) {
        this.models = models;
        this.ctx = ctx;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View v = LayoutInflater.from(viewGroup.getContext())
                .inflate(R.layout.item_diary, viewGroup, false);
        return new ViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder viewHolder, final int i) {
        final RemindModel model = models.get(i);

        viewHolder.textViewName.setText(model.getTitle());
        viewHolder.textViewDate.setText(model.getDate());
        viewHolder.textViewDesc.setText(model.getDescription());

        viewHolder.container.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(ctx, DetailActivity.class);
                intent.putExtra("DATA",model);

                ctx.startActivity(intent);            }
        });
        if (!model.getDate().equals("Wed, 22 Des")) {
            Context context = viewHolder.itemView.getContext();
            Resources resources = context.getResources();
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN) {
                viewHolder.itemView.setBackground(resources.getDrawable(R.drawable.red_rounded_rectangle));
            }
        }
    }

    @Override
    public int getItemCount() {
        return models.size();
    }

    class ViewHolder extends RecyclerView.ViewHolder {
        TextView textViewName;
        TextView textViewDesc;
        TextView textViewDate;

        View container;

        ViewHolder(@NonNull View itemView) {
            super(itemView);
            textViewName = itemView.findViewById(R.id.item_diary_title);
            textViewDesc = itemView.findViewById(R.id.item_diary_desc);
            textViewDate = itemView.findViewById(R.id.item_diary_time);
            container = itemView.findViewById(R.id.item_container);
        }
    }
}
