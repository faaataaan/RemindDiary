package org.d3ifcool.reminddiary;

import android.os.Parcel;
import android.os.Parcelable;

public class RemindModel implements Parcelable {
    private int id;
    private String date;
    private String title;
    private String description;

    public RemindModel(int id, String date, String title, String description) {
        this.id = id;
        this.date = date;
        this.title = title;
        this.description = description;
    }


    protected RemindModel(Parcel in) {
        id = in.readInt ();
        date = in.readString ();
        title = in.readString ();
        description = in.readString ();
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeInt (id);
        dest.writeString (date);
        dest.writeString (title);
        dest.writeString (description);
    }

    @Override
    public int describeContents() {
        return 0;
    }

    public static final Creator <RemindModel> CREATOR = new Creator <RemindModel> () {
        @Override
        public RemindModel createFromParcel(Parcel in) {
            return new RemindModel (in);
        }

        @Override
        public RemindModel[] newArray(int size) {
            return new RemindModel[size];
        }
    };

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }
}
