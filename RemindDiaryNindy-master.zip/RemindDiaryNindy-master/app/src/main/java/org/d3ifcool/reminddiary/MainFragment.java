package org.d3ifcool.reminddiary;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.provider.BaseColumns;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.DividerItemDecoration;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import java.util.ArrayList;

public class MainFragment extends Fragment {
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = LayoutInflater.from(container.getContext())
                .inflate(R.layout.fragment_main, container, false);
        Bundle bundle = getArguments();
        int type = bundle.getInt("type");

        ArrayList<RemindModel> reminds;
        reminds = (type == 0) ? getDiary() : getReminder();
        RemindAdapter adapter = new RemindAdapter(getContext(),reminds);

        RecyclerView recyclerView = view.findViewById(R.id.fragment_main_recyler_view);
        recyclerView.setAdapter(adapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(container.getContext()));
        recyclerView.addItemDecoration(new DividerItemDecoration(container.getContext(), LinearLayoutManager.HORIZONTAL));
        return view;
    }

    private ArrayList<RemindModel> getReminder() {
        ArrayList<RemindModel> reminds = new ArrayList<>();

        return reminds;
    }

    private ArrayList<RemindModel> getDiary() {
        ArrayList<RemindModel> reminds = new ArrayList<>();
        DBHELPER dbHelper = new DBHELPER(getContext());
        SQLiteDatabase db = dbHelper.getReadableDatabase();

// Define a projection that specifies which columns from the database
// you will actually use after this query.
        String[] projection = {
                DatabaseContract.DiaryEntry._ID,
                DatabaseContract.DiaryEntry.COLUMN_TITLE,
                DatabaseContract.DiaryEntry.COLUMN_DATE,
                DatabaseContract.DiaryEntry.COLUMN_BODY
        };


        Cursor cursor = db.query(
                DatabaseContract.DiaryEntry.TABLE_NAME,   // The table to query
                projection,             // The array of columns to return (pass null to get all)
                null,              // The columns for the WHERE clause
                null,          // The values for the WHERE clause
                null,                   // don't group the rows
                null,                   // don't filter by row groups
                null               // The sort order
        );
        while(cursor.moveToNext()) {
            RemindModel item = new RemindModel(
                    cursor.getInt (cursor.getColumnIndexOrThrow(DatabaseContract.DiaryEntry._ID)),
                cursor.getString(cursor.getColumnIndexOrThrow(DatabaseContract.DiaryEntry.COLUMN_DATE)),
                cursor.getString(cursor.getColumnIndexOrThrow(DatabaseContract.DiaryEntry.COLUMN_TITLE)),
                cursor.getString(cursor.getColumnIndexOrThrow(DatabaseContract.DiaryEntry.COLUMN_BODY))
            );
            reminds.add(item);
        }
        cursor.close();
        return reminds;
    }

}
