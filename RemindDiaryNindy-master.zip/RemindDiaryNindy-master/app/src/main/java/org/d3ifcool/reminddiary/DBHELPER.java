package org.d3ifcool.reminddiary;

import android.content.Context;
import android.database.DatabaseErrorHandler;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DBHELPER extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "diary.db";
    private static final int DATABASE_VERSION = 1;
//    public DBHELPER(Context context) {
//        super(context, DATABASE_NAME, null, DATABASE_VERSION);
//
//        // TODO Auto-generated constructor stub
//    }

    public DBHELPER(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }




    public void onCreate(SQLiteDatabase db) {
        String sql = "CREATE TABLE " + DatabaseContract.DiaryEntry.TABLE_NAME + " (" +
                DatabaseContract.DiaryEntry._ID + " INTEGER PRIMARY KEY," +
                DatabaseContract.DiaryEntry.COLUMN_TITLE + " TEXT," +
                DatabaseContract.DiaryEntry.COLUMN_DATE + " TEXT," +
                DatabaseContract.DiaryEntry.COLUMN_BODY + " TEXT)";

        String sql2 = "CREATE TABLE " + DatabaseContract.RemindEntry.TABLE_NAME + " (" +
                DatabaseContract.RemindEntry._ID + " INTEGER PRIMARY KEY," +
                DatabaseContract.RemindEntry.COLUMN_TITLE + " TEXT," +
                DatabaseContract.RemindEntry.COLUMN_DATE + " TEXT," +
                DatabaseContract.RemindEntry.COLUMN_REPEAT + " TEXT," +
                DatabaseContract.RemindEntry.COLUMN_IMAGE + " TEXT)";
        db.execSQL(sql);
        db.execSQL(sql2);

    }
    private static final String SQL_DELETE_ENTRIES =
            "DROP TABLE IF EXISTS " + DatabaseContract.DiaryEntry.TABLE_NAME;

    private static final String KEY_NAME = "image_name";
    private static final String KEY_IMAGE = "image_data";




    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // This database is only a cache for online data, so its upgrade policy is
        // to simply to discard the data and start over
        db.execSQL(SQL_DELETE_ENTRIES);
        onCreate(db);
    }
    public void onDowngrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        onUpgrade(db, oldVersion, newVersion);
    }


}
