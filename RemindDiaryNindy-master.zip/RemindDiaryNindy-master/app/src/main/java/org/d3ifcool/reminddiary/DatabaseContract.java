package org.d3ifcool.reminddiary;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.provider.BaseColumns;

public final class DatabaseContract{
    // To prevent someone from accidentally instantiating the contract class,
    // make the constructor private.
    private DatabaseContract() {}

    /* Inner class that defines the table contents */
    public static class DiaryEntry implements BaseColumns {
        public static final String TABLE_NAME = "ADD_DIARY";
        public static final String COLUMN_TITLE= "title";
        public static final String COLUMN_DATE= "date";
        public static final String COLUMN_BODY= "body";

    }

    public static class RemindEntry implements BaseColumns {
        public static final String TABLE_NAME = "ADD_REMINDER";
        public static final String COLUMN_TITLE= "title_r";
        public static final String COLUMN_DATE= "date_r";
        public static final String COLUMN_REPEAT= "repeat_r";
        public static final String COLUMN_IMAGE= "image";
    }



}
